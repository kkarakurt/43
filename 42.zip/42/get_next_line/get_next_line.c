/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kkarakur <kkarakur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/20 14:56:50 by kkarakur          #+#    #+#             */
/*   Updated: 2023/09/02 15:40:09 by kkarakur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <unistd.h>

static char	*copy_to_next_line(char *next_line, char *buf)
{
	char	*res;

	res = 0;
	if (!next_line && buf)
	{
		res = ft_strdup(buf);
		if (!res)
			return (NULL);
		return (res);
	}
	res = ft_strjoin(next_line, buf);
	free_next_line(&next_line, 1);
	return (res);
}

static int	new_line_controller(char *s)
{
	size_t	i;

	if (!s)
		return (0);
	i = -1;
	while (s[++i])
		if (s[i] == '\n')
			return (1);
	return (0);
}

static char	*copy_to_this_line(char *next_line)
{
	char	*this_line;
	size_t	i;
	size_t	j;

	i = 0;
	if (!next_line)
		return (free_next_line(&next_line, 1));
	while (next_line[i] != '\n')
		i++;
	this_line = malloc(sizeof(char) * (i + 2));
	if (!this_line)
		return (free_next_line(&this_line, 1));
	j = 0;
	while (j < i + 1)
	{
		this_line[j] = next_line[j];
		j++;
	}
	this_line[j] = '\0';
	return (this_line);
}

static char	*create_next_line(char *next_line)
{
	size_t	i;
	char	*res;

	i = 0;
	if (!next_line)
		return (NULL);
	while (next_line[i] != '\n')
		i++;
	if (!next_line[i + 1])
		return (free_next_line(&next_line, 1));
	res = ft_substr(next_line, i + 1, ft_strlen(next_line));
	if (!res)
	{
		free_next_line(&next_line, 1);
		return (NULL);
	}
	free_next_line(&next_line, 1);
	return (res);
}

char	*get_next_line(int fd)
{
	char		buf[BUFFER_SIZE + 1];
	long		ret;
	static char	*next_line;
	char		*this_line;

	ret = BUFFER_SIZE;
	if (fd < 0 || BUFFER_SIZE <= 0)
		return (free_next_line(&next_line, 1));
	while (ret > 0)
	{
		ret = read(fd, buf, BUFFER_SIZE);
		if ((ret <= 0 && !next_line) || ret == -1)
			return (free_next_line(&next_line, 1));
		buf[ret] = '\0';
		next_line = copy_to_next_line(next_line, buf);
		if (new_line_controller(next_line))
		{
			this_line = copy_to_this_line(next_line);
			if (!this_line)
				return (free_next_line(&next_line, 1));
			return (next_line = create_next_line(next_line), this_line);
		}
	}
	return (free_next_line(&next_line, 0));
}
